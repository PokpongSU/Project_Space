package com.example.simpleintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button button; // เรียกใช้ method Button โดยให้ใช้คุณสมบัตินี้ในชื่อของ button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ประกาศใช้ button = (Button) เพื่อให้มีคุณสมบัติที่สามารถเปิดใช้งานได้ ภายใต้ตัวแปรที่ชื่อว่า button
        // โดยกำหนดให้เป็นปุ่มที่ใช้ชื่อ id ว่า mybtn (อยู่ในส่วนของ activity_main.xml)
        // ประกาศใช้งาน button ให้สามารถทำหน้าที่ setOnClickListener(เปืดหน้าใหม่เมื่อกดปุ่ม)
        // ประกาศเรียกใช้งาน public void onClick(View view) { openActivity2(); }
        // ทำหน้าที่เปิดใช้งานคุณสมบัติที่ถูกใส่ไว้ใน method ที่ชื่อว่า openActivity2
        // Tips : ในส่วนของ openActivity2(); คือชื่อของ method ที่ตั้งขึ้นมา สามารถใช้ชื่ออื่นได้

        button = (Button) findViewById(R.id.mybtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2();
            }
        });
    }


    // เซ็ตค่าคุณสมบัติให้กับ method ของ openActivity2()
    // เรียกใช้งานฟังก์ชั่น Intent โดยใช้ชื่อใหม่ให้คือ intent และมอบคุณสมบัติที่สามารถเปลี่ยนไปยังหน้าใหม่ได้ คือ new Intent(...);
    // ในส่วนที่อยู่ใน (this, MainActivity2.class); หมายความว่า จากหน้านี้ ไปยังหน้าที่กำหนด
    // startActivity(intent); คือ method ที่เรียกใช้งานอีกหน้าโดยการ(เปลี่ยนไปหน้านั้น)
    public void openActivity2() {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
}