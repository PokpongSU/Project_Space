package com.example.simpleonclicklistener;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button; // import ปุ่มมาใช้
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // เรียกใช้ Widget ปุ่มมา แล้วประกาศใช้ชื่อ btn แทน และให้คุณสมบัติทำหน้าที่ findViewById(โดยกำหนดให้เป็นปุ่มที่ชื่อ btnOK)
        Button btn = findViewById(R.id.btnOK);

        // มอบคุณสมบัติ OnClickListener ให้กับ btn ทำหน้าที่ตามสิ่งที่อยู่ในวงเล็บ
        // ในส่วนของ View.OnClickListener() ระบุคุณสมบัติเพิ่มเติมด้วย {} ว่ากำหนดให้ method onClick(View view)
        // สามารถแสดงสิ่งที่เซ็ตไว้ข้างใน{} คือ Toast pop-up ขึ้นมาว่า "CLICKED !!!"
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "CLICKED !!", Toast.LENGTH_LONG).show();

            }
        });
    }
}